#include "Energia.h"

#line 1 "C:/Users/Notebook/Desktop/Porject Files/j4210u-driver-mcu/j4210u-driver.ino"





#include "J4210U.h"


#define LED RED_LED



void getMemoryContent(J4210U &uhf, ScanData *sd);
void getTID(J4210U &uhf, ScanData *sd);
void getTagInfo(J4210U &uhf, ScanData *sd);
int getInventory(J4210U &uhf);
void setup();
void loop();

#line 13
void getMemoryContent(J4210U &uhf, ScanData *sd) {

}

void getTID(J4210U &uhf, ScanData *sd) {
    cprintf(">>> getTID() STARTED:\n");
    char epcnum[sd->epclen*2];
    bytes2hex(sd->EPCNUM, sd->epclen, epcnum);
    cprintf("Getting TID for EPCNUM: %s\n", epcnum);

    unsigned char tid[16];
    unsigned char tidlen = 0;
    if (!uhf.GetTID(sd->EPCNUM,sd->epclen,tid,&tidlen)) {
        
        char str[32];
        bytes2hex(sd->EPCNUM, sd->epclen, str);
        cprintf("TID: %s\n", str);
    } else {
        cprintf("Failed to obtain TID.\n");
    }
    cprintf("getInventory() ENDED <<<\n");
}

void getTagInfo(J4210U &uhf, ScanData *sd) {

}

int getInventory(J4210U &uhf) {
    cprintf(">>> getInventory() STARTED:\n");
    ReaderInfo ri;
    uhf.GetSettings(&ri);
    uhf.printsettings(&ri);

    ri.ScanTime = 200;
    ri.BeepOn = 0;
    if (!uhf.SetSettings(&ri)) {
        cprintf("Failed to set settings.\n");
    } else {
        uhf.GetSettings(&ri);
        uhf.printsettings(&ri);
    }
    int n = uhf.Inventory(false);
    cprintf("Found %d tags.\n", n);
    for(int i=0;i<n;i++) {
        uhf.printtag(i);
    }
    cprintf("getInventory() ENDED <<<\n");
    return n;
}


void setup() {
  
  pinMode(LED, OUTPUT);

  Serial.begin(115200);
  J4210U uhf(&Serial7, 57600);

  int n = getInventory(uhf);
  for(int i=0;i<n;i++) {
      ScanData *sd = uhf.GetResult(i);
      if (sd == 0)
          break;
      cprintf("Getting TID for tag %d\n", i);
      unsigned char tid[16];
      unsigned char tidlen = 0;
      if (uhf.GetTID(sd->EPCNUM,sd->epclen,tid,&tidlen)) {
          uhf.printtag(i);
          char str[32];
          bytes2hex(tid, tidlen, str);
          cprintf("TID: %s\n", str);
      }
  }
}


void loop() {
    
  digitalWrite(LED, HIGH);   
  delay(1000);               
  digitalWrite(LED, LOW);    
  delay(1000);               
  Serial.println("This is TivaC");
}



